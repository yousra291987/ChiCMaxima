#!/usr/bin/env perl.exe
use strict;
use diagnostics;

if ($#ARGV != 3) {
	print STDERR "usage: $0 <bam file> <baitmap file> <rmap file> <output>\n";
	exit 1;
}

my $bam = $ARGV[0];
my $bmap = $ARGV[1];
my $rmap = $ARGV[2];
my $ofn = $ARGV[3];

my @split = split(/\./,$bam);
my $bambase = $split[0];
my $tmp = $bambase.".bedpe";

print "Converting bam to bedpe with bedtools...\n";
system("bedtools pairtobed -abam $bam -bedpe -b $bmap -f 0.6 > $tmp")==0 or die $!;

print "Converting $tmp to ChicMaxima input...\n";
system("perl ./align2ibed.pl $tmp $bmap $rmap $ofn 1 2 4 5")==0 or die $!;

